/*
 * slp.h
 *
 *  Created on: Sep 18, 2018
 *      Author: user1
 */

#ifndef SLP_H_
#define SLP_H_



#endif /* SLP_H_ */


void slp(void);
void blocksleepmode(int);
void unblocksleepmode(int);
